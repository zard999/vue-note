# typora-theme-orange-heart

[[English](README.md) | 中文]

## 1 介绍


> 样式基于 `markdown-nice` 的[橙心](https://preview.mdnice.com/themes/id/1)主题修改，作者为 [zhning12](https://github.com/zhning12)；
>
> 代码框样式基于 `typora` 的 [typora-theme-pie](https://github.com/kevinzhao2233/typora-theme-pie) 主题修改，作者为 [kevinzhao2233](https://github.com/kevinzhao2233)。

这份样式源自使用 [markdown-nice](https://github.com/mdnice/markdown-nice) 处理 `Markdown` 样式时，想在 `Typora` 上使用的想法。目前大体样式已相同，可正常使用。

## 2 安装

① `Typora` 软件：文件->偏好设置(->外观)->主题->打开主题文件夹；

②  将 `orangeheart.css` 文件复制粘贴至 `Typora` 主题文件夹；

③  重启软件。

## 3 截图

![typora_theme_orange_heart](./assets/typora_theme_orange_heart.png)

## 4 其他

* [Typora 主题](http://theme.typora.io/)

MIT @ evgo2017
